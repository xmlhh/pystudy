#! /usr/bin/python3
#-*- coding:utf-8 -*-

def send_msg(msg):
    print('发送的消息： %s' % msg)