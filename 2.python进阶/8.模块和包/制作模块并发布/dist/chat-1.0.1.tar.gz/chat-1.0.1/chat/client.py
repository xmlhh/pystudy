#! /usr/bin/python3
#-*- coding:utf-8 -*-

def recv_msg():
    return '接收来自 server 的消息'